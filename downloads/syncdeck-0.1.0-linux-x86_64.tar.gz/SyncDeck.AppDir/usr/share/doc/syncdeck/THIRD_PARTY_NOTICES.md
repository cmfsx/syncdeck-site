# Third-Party Notices and Licences

SyncDeck incorporates or links with several open-source libraries and components. We are deeply grateful to their authors and maintainers.

---

### 1. rclone
* **Website:** https://rclone.org/
* **Licence:** MIT Licence
* **Copyright:** (C) 2012-2026 Nick Craig-Wood and rclone contributors
* **Usage:** Cloud storage transfer worker, FUSE virtual drive provider, and loopback restic server.

### 2. rustic_core / rustic
* **Website:** https://rustic.cli.rs/
* **Licence:** Apache-2.0 or MIT Licence
* **Copyright:** (C) 2022-2026 rustic contributors
* **Usage:** Restic-compatible backup repository format, content deduplication, and cryptographic verification.

### 3. Tauri
* **Website:** https://tauri.app/
* **Licence:** Apache-2.0 or MIT Licence
* **Copyright:** (C) 2019-2026 Tauri Programme within The Commons Conservancy
* **Usage:** Native desktop application framework and webview shell.

### 4. rusqlite / SQLite
* **Website:** https://github.com/rusqlite/rusqlite
* **Licence:** MIT Licence (rusqlite) / Public Domain (SQLite)
* **Usage:** Embedded transactional local state database in WAL mode.

### 5. Tokio
* **Website:** https://tokio.rs/
* **Licence:** MIT Licence
* **Copyright:** (C) Tokio Contributors
* **Usage:** Asynchronous runtime for the `syncdeck-daemon` service.

### 6. Security patch to rustic_core

The distributed `vendor/rustic_core` tree is the published 0.13.0 crate under
Apache-2.0 OR MIT. Original source notices are preserved. Standalone MIT and Apache license texts,
which were absent from the published crate archive, are supplied from its exact
upstream source revision and hashed in the patch provenance record. SyncDeck
changes only the normalized Cargo manifest to require zstd 0.14.3 and remove an
obsolete Rust lint. The dependency update fixes the
reported compression advisories without changing the restic repository format.
`SYNCDECK-PATCH.json` records archive provenance and all upstream file hashes;
`scripts/verify-vendored.py` verifies the narrow patch. Remove this patch when a
maintained upstream release includes the corrected dependency.

### 7. MPL 2.0 and LLVM-exception dependencies

The following dependency source is used without modification under MPL-2.0:
option-ext 0.2.0, cssparser 0.37.0, cssparser-macros 0.7.1, dtoa-short 0.3.5,
and selectors 0.38.0. Original license and copyright notices remain applicable.
Source archives for these exact versions are available from crates.io, e.g.
`https://crates.io/api/v1/crates/option-ext/0.2.0/download`, with the corresponding
crate name/version for the other entries. Release source bundles also contain
these dependencies and their original notices. When distributed as part of the
GPL-3.0-or-later larger work, MPL-covered source is additionally available under
GPL-3.0-or-later pursuant to MPL 2.0 section 3.3; the original MPL rights remain.
No Exhibit B restriction was found in the covered source headers examined.

The target-lexicon 0.12.16 dependency is Apache-2.0 WITH LLVM-exception. Its
original license text is included in dependency source bundles. Reviewed policy
permissions are restricted to the named versions; other licenses remain checked.

References: [Mozilla MPL FAQ Q14](https://www.mozilla.org/en-US/MPL/2.0/FAQ/#may-i-combine-mpl-licensed-code-and-lgpl-licensed-code-in-the-same-executable-program),
[LLVM license policy](https://llvm.org/docs/DeveloperPolicy.html#copyright-license-and-patents).

## rustic_backend strict REST safety patch

`vendor/rustic_backend` retains the upstream 0.7.0 MIT/Apache-2.0 notices.
SyncDeck changes only REST existence/listing error handling, redirect policy and
retry error redaction. Unknown/failed listings cannot become empty inventories;
invalid or duplicate object IDs fail the listing. The verified upstream archive
checksum and reversible source edits are recorded in `SYNCDECK-PATCH.json` and
checked by `scripts/verify-vendored.py`. Exact patched source is included in the
third-party source archive. Default desktop cloud jobs remain disabled pending
managed lifecycle and live provider validation.
